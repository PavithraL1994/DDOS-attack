 java -cp ./geoip-api-1.2.10.jar:. SlaveBot -h psglx64 -p 9999
  java -cp . MasterBot -p 9999
